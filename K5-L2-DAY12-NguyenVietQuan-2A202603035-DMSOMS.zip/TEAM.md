# TEAM — Ngày 12

Mã bộ ảnh: **G03** · Hình thức: cá nhân

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với (peer diff) | Số dòng disagreement đã xử lý |
|---|---|---|---|---:|
| Nguyễn Việt Quân | 2A202603035 | Có | Nguyễn Thị Thúy An | 55 |

Ca còn chưa thống nhất, cần hỏi coach: các dòng `ambiguous` trong disagreement log.

## Cá nhân

### NguyenVietQuan-2A202603035
- Phần mình làm: Tự gán 22 ảnh và review chéo với Nguyễn Thị Thúy An.
- Điều mình học được hôm nay: Luôn kiểm tra lại thuộc tính trong Details.
